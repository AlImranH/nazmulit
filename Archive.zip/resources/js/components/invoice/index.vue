<template>
    <h1>Invoice index</h1>
</template>
