<template>
    <h1>Page Not Found</h1>
    <router-link to="/"> Back to home page</router-link>
</template>
